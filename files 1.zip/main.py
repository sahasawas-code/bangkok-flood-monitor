"""
BANGKOK FLOOD MONITOR - Backend (V1)
=====================================
ทำหน้าที่เป็นตัวกลาง (backend proxy) ระหว่าง frontend กับแหล่งข้อมูลจริง (TMD)
เหตุผล: หลีกเลี่ยงปัญหา CORS, ควบคุม cache, จัดการ error, และเผื่อรวมแหล่งข้อมูลอื่น
ในอนาคต (BMA / RID / ThaiWater) ตามที่วางแผนไว้ในเอกสารโครงการ

หลักการที่ยึดตามเอกสาร (ข้อ 29):
- ไม่สร้างข้อมูลปลอม / ไม่เดาค่า
- ทุกข้อมูลต้องมี timestamp ของแหล่งต้นทาง (Last-Modified) และเวลาที่เราดึงมา (fetched_at)
- ถ้าต้นทางล่าช้า -> ต้องบอกว่า stale
- ถ้าต้นทางล่ม -> ต้องบอกสถานะ error ตรงๆ ไม่เงียบ ไม่เดา
- ไม่เรียกว่า realtime ถ้ามันไม่ใช่ realtime จริง (เราจะเรียกว่า near-real-time)

*** อัปเดตจากภาพ DevTools ที่ผู้ใช้ส่งมา (Preview ของ Network) ***
ยืนยันแล้วว่าโครงสร้างจริงคือ:

rain_bkk_latest.json =>
{
  "updated_at": "2026-09-27 15:06:15",
  "stations": [
    {"id": "1316693", "lat": 12.457138, "lon": 99.794328,
     "province": "ประจวบคีรีขันธ์", "amphoe": "ปราณบุรี", ... (ยังมี field อื่นที่ถูกตัดใน preview)}
  ]
}

rain_bkk_hourly.json =>
{
  "anchor_time_thai": "2026-07-09 07:00",
  "date_utc": "2026-07-09",
  "elapsed_hours": 1,
  "hours_utc": [0, 1],
  "updated_at": "2026-07-09 08:06:09",
  "stations": [
    {"id": "1316693", "lat": 12.457138, "lon": 99.794328,
     "province_th": "ประจวบคีรีขันธ์", ... (ยังมี field อื่นที่ถูกตัดใน preview)}
  ]
}

*** ยืนยันฟิลด์ค่าฝนแล้ว จากข้อความ Preview ที่ผู้ใช้ copy มา (station id "97") ***
สถานีนั้นแสดงเต็มว่า:
{id, lat, lon, province, amphoe, rain_1h: 0, rain_24h: 92.2, time: "2026-09-27 16:00"}

ดังนั้นสรุปฟิลด์จริงของ rain_bkk_latest.json ต่อสถานีคือ:
  id, lat, lon, province, amphoe, rain_1h, rain_24h, time

(rain_bkk_hourly.json ยังไม่เห็นฟิลด์ค่าฝนแบบเต็ม มีแค่ id/lat/lon/province_th/province_en
ที่กางออก - ฟิลด์ค่าฝนของไฟล์นี้อาจต่างออกไป เพราะมันผูกกับ hours_utc [0,1] คือ 2 ชั่วโมง
ยังต้องกางดูอีกทีถ้าจะใช้ endpoint /api/rain/hourly จริงจัง - ตอนนี้ยังใช้ candidate เดิมไปก่อน)
"""

import time
import httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Bangkok Flood Monitor API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # ปรับให้เจาะจงขึ้นก่อนเผยแพร่จริง
    allow_methods=["GET"],
    allow_headers=["*"],
)

TMD_BASE = "https://satda.tmd.go.th/wp-content/uploads/nowcasting/bkk"
SOURCES = {
    "rain_latest": f"{TMD_BASE}/rain_bkk_latest.json",
    "rain_hourly": f"{TMD_BASE}/rain_bkk_hourly.json",
    "manifest": f"{TMD_BASE}/manifest.json",
}

# แคชในหน่วยความจำ กันยิง TMD ถี่เกินไป (ปรับ TTL ตามความถี่จริงของแหล่งข้อมูล
# เอกสารสังเกตว่า rain_bkk_latest.json เห็น Last-Modified ห่างกันประมาณ 10-25 นาที
# ให้ตั้ง TTL เท่ากับรอบอัปเดตจริง หลังจากยืนยันด้วยการสังเกตหลายรอบ)
CACHE_TTL_SECONDS = 300  # 5 นาที (ค่าตั้งต้น - ต้องปรับตามพฤติกรรมจริงของแหล่งข้อมูล)
_cache: dict[str, dict] = {}

# ----------------------------------------------------------------------------
# ยืนยันแล้วจากข้อความ Preview (station id "97"): rain_1h, rain_24h, time คือฟิลด์จริง
# ----------------------------------------------------------------------------
FIELD_CANDIDATES = {
    "lat": ["lat", "latitude"],
    "lon": ["lon", "lng", "longitude"],
    "id": ["id", "station_id", "code"],
    "area_name": ["amphoe", "province_th", "province", "district", "name"],
    "rainfall_1h": ["rain_1h"],
    "rainfall_24h": ["rain_24h"],
    "timestamp": ["time", "timestamp", "datetime", "obsTime", "obs_time"],
}


def _find_field(record: dict, candidates: list[str]):
    for key in candidates:
        if key in record:
            return record[key]
    return None


def normalize_rain_record(record: dict) -> dict:
    """แปลง station record แบบดิบให้เป็นรูปแบบกลางที่ frontend ใช้ได้แน่นอน
    ฟิลด์ยืนยันแล้ว: id, lat, lon, province, amphoe, rain_1h, rain_24h, time
    "_raw" เก็บของดิบทั้งหมดไว้เสมอ เผื่อมีฟิลด์อื่นที่ยังไม่ map
    """
    province = record.get("province") or record.get("province_th")
    amphoe = record.get("amphoe")
    area_name = ", ".join([p for p in [amphoe, province] if p]) or None

    return {
        "id": _find_field(record, FIELD_CANDIDATES["id"]),
        "lat": _find_field(record, FIELD_CANDIDATES["lat"]),
        "lon": _find_field(record, FIELD_CANDIDATES["lon"]),
        "station": area_name,
        "rainfall": _find_field(record, FIELD_CANDIDATES["rainfall_1h"]),
        "rainfall_24h": _find_field(record, FIELD_CANDIDATES["rainfall_24h"]),
        "timestamp": _find_field(record, FIELD_CANDIDATES["timestamp"]),
        "_raw": record,
    }


async def fetch_source(key: str) -> dict:
    """ดึงข้อมูลจาก TMD พร้อม cache, timestamp, และ error handling ตรงไปตรงมา"""
    now = time.time()
    cached = _cache.get(key)
    if cached and (now - cached["fetched_at_epoch"]) < CACHE_TTL_SECONDS:
        return cached

    url = SOURCES[key]
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url, headers={"User-Agent": "BangkokFloodMonitor/0.1"})
        resp.raise_for_status()
        payload = resp.json()
        last_modified = resp.headers.get("Last-Modified")
        result = {
            "ok": True,
            "error": None,
            "source_url": url,
            "source_last_modified": last_modified,
            "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "fetched_at_epoch": now,
            "data": payload,
        }
    except Exception as exc:  # ไม่ปกปิด error - แสดงตรงๆ ตามหลักการข้อ 8
        result = {
            "ok": False,
            "error": f"{type(exc).__name__}: {exc}",
            "source_url": url,
            "source_last_modified": None,
            "fetched_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "fetched_at_epoch": now,
            "data": None,
        }

    _cache[key] = result
    return result


def is_stale(source_last_modified: str | None, threshold_minutes: int = 30) -> bool | None:
    """คืนค่า True ถ้าข้อมูลต้นทางเก่ากว่า threshold - ยังไม่ implement การ parse วันที่แบบ
    เข้มงวด เพราะยังไม่รู้ format แน่ชัดของ header ในทุกกรณี ปรับตอนเห็นของจริง"""
    if not source_last_modified:
        return None
    return None  # TODO: parse และเทียบเวลาจริงหลังยืนยัน format


@app.get("/api/status")
async def status():
    """สถานะรวมของทุกแหล่งข้อมูล - ใช้โชว์ banner บน dashboard"""
    out = {}
    for key in SOURCES:
        r = await fetch_source(key)
        out[key] = {
            "ok": r["ok"],
            "error": r["error"],
            "source_last_modified": r["source_last_modified"],
            "fetched_at": r["fetched_at"],
        }
    return out


@app.get("/api/rain/latest")
async def rain_latest():
    r = await fetch_source("rain_latest")
    if not r["ok"]:
        return {"ok": False, "error": r["error"], "fetched_at": r["fetched_at"], "records": []}

    raw = r["data"]
    # ยืนยันแล้ว: โครงสร้างจริงคือ dict ที่มี "stations" (list) และ "updated_at"
    records_raw = raw.get("stations", []) if isinstance(raw, dict) else []
    records = [normalize_rain_record(rec) for rec in records_raw if isinstance(rec, dict)]

    return {
        "ok": True,
        "error": None,
        "source_url": r["source_url"],
        "source_last_modified": r["source_last_modified"],
        "source_updated_at": raw.get("updated_at") if isinstance(raw, dict) else None,
        "fetched_at": r["fetched_at"],
        "is_realtime_note": "near-real-time ตามรอบอัปเดตของ TMD ไม่ใช่ realtime แบบวินาทีต่อวินาที",
        "record_count": len(records),
        "records": records,
    }


@app.get("/api/rain/hourly")
async def rain_hourly():
    r = await fetch_source("rain_hourly")
    if not r["ok"]:
        return {"ok": False, "error": r["error"], "fetched_at": r["fetched_at"], "records": []}

    raw = r["data"]
    records_raw = raw.get("stations", []) if isinstance(raw, dict) else []
    records = [normalize_rain_record(rec) for rec in records_raw if isinstance(rec, dict)]

    return {
        "ok": True,
        "error": None,
        "source_url": r["source_url"],
        "source_last_modified": r["source_last_modified"],
        "source_updated_at": raw.get("updated_at") if isinstance(raw, dict) else None,
        "anchor_time_thai": raw.get("anchor_time_thai") if isinstance(raw, dict) else None,
        "date_utc": raw.get("date_utc") if isinstance(raw, dict) else None,
        "hours_utc": raw.get("hours_utc") if isinstance(raw, dict) else None,
        "elapsed_hours": raw.get("elapsed_hours") if isinstance(raw, dict) else None,
        "fetched_at": r["fetched_at"],
        "record_count": len(records),
        "records": records,
    }


@app.get("/api/debug/raw-latest")
async def debug_raw_latest():
    """เปิดหน้านี้ก่อนใช้งานจริง! ดูโครงสร้าง JSON ดิบของ rain_bkk_latest.json
    เพื่อเอาไปแก้ FIELD_CANDIDATES ด้านบนให้ตรงกับของจริง"""
    r = await fetch_source("rain_latest")
    return r


@app.get("/api/debug/raw-hourly")
async def debug_raw_hourly():
    r = await fetch_source("rain_hourly")
    return r


@app.get("/")
async def root():
    return {
        "name": "Bangkok Flood Monitor API",
        "status": "ok",
        "next_step": "เปิด /api/debug/raw-latest เพื่อดูโครงสร้าง JSON จริงก่อนใช้งาน",
        "endpoints": ["/api/status", "/api/rain/latest", "/api/rain/hourly",
                      "/api/debug/raw-latest", "/api/debug/raw-hourly"],
    }
