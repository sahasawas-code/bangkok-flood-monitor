# BANGKOK FLOOD MONITOR — V1 (ฝน + แผนที่)

สร้างตามเอกสารสรุปบทสนทนา/แผนโครงการที่แนบมา (`bangkok_flood_monitor_conversation_notes.txt`)
นี่คือ **จุดเริ่ม V1** ตามแผนใน Section 15 ของเอกสาร: ดึงข้อมูลฝนจาก TMD Nowcasting กรุงเทพฯ
แสดงบนแผนที่ Leaflet ผ่าน backend ของเราเอง (แก้ปัญหา CORS ตาม Section 22)

## ✅ ยืนยันโครงสร้างข้อมูลฝนแล้ว (จากข้อความ Preview จริง)

ต่อ 1 สถานีใน `rain_bkk_latest.json`:

```
{id, lat, lon, province, amphoe, rain_1h, rain_24h, time}
```

ตัวอย่างจริง: `{id: "97", lat: 14.60885, lon: 101.07645, province: "สระบุรี",
amphoe: "แก่งคอย", rain_1h: 0, rain_24h: 92.2, time: "2026-09-27 16:00"}`

Backend (`backend/main.py`) แก้ให้อ่าน `rain_1h` เป็นค่าฝนหลัก และ `rain_24h` เป็นค่าฝนสะสม
24 ชม. แล้ว — ไม่ใช่การเดาอีกต่อไป

**ที่ยังไม่ยืนยัน:** `rain_bkk_hourly.json` — ตัวอย่างที่ได้มายังไม่กางฟิลด์ค่าฝนออกมา
เห็นแค่ `id, lat, lon, province_th, province_en` เพราะไฟล์นี้ผูกกับ `hours_utc` (เช่น `[0, 1]`)
ค่าฝนของไฟล์นี้อาจอยู่ในรูปแบบอื่น (เช่น array ต่อชั่วโมง) ตอนนี้ endpoint `/api/rain/hourly`
ยังใช้ field เดียวกับ latest ไปก่อน ถ้าจะใช้ข้อมูลย้อนหลังจริงจัง ต้องกางสถานีในไฟล์นี้ให้เต็ม
อีกรอบ (เอา JSON แบบ Response เต็ม ไม่ใช่ Preview ที่ย่อ)

## วิธีรัน (แบบ local หรือบน Replit)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

จากนั้นเปิดไฟล์ `frontend/index.html` ในเบราว์เซอร์ (หรือใช้ VS Code Live Server / `python -m http.server`)
ถ้ารันบน Replit ให้แก้ค่า `BACKEND_URL` ในไฟล์ `frontend/index.html` ให้เป็น URL ของ Repl ที่ deploy ไว้

## โครงสร้างโปรเจกต์

```
backend/
  main.py            FastAPI: proxy + cache + normalize ข้อมูลฝนจาก TMD
  requirements.txt
frontend/
  index.html         Dashboard + Leaflet map (เรียก backend ของเราเอง ไม่เรียก TMD ตรง)
```

## หลักการที่ยึดไว้ในโค้ด (ตาม Section 29 ของเอกสาร)

- ไม่เดา/ไม่ปั้นค่าฝนหรือค่าใดๆ — ถ้าหา field ไม่เจอ ระบบจะโชว์ `null` ตรงๆ ไม่ใช่ค่าที่แต่งขึ้น
- ทุก response มี `source_last_modified` (จาก header ของ TMD) และ `fetched_at` (เวลาที่เราดึง)
- ถ้าดึงข้อมูลจาก TMD ไม่ได้ → `ok: false` + `error` message ตรงๆ ไม่ใช่ค่าว่างเงียบๆ
- เรียกข้อมูลว่า **near-real-time** ไม่ใช่ realtime เพราะขึ้นกับรอบอัปเดตของ TMD
- backend เป็นตัวกลาง ไม่ให้ browser ยิงตรงไป TMD (กัน CORS + คุม cache)

## Checklist ขั้นต่อไป (คัดจาก Section 33 ของเอกสาร)

- [x] ยืนยันโครงสร้าง JSON ของ `rain_bkk_latest.json` (rain_1h, rain_24h, time)
- [ ] ยืนยันโครงสร้างค่าฝนของ `rain_bkk_hourly.json` (ยังไม่กางฟิลด์เต็ม)
- [ ] ตรวจ `manifest.json`, `bounds.json`, GeoJSON ว่ามี metadata อะไรเพิ่ม
- [ ] ตรวจความถี่อัปเดตจริง แล้วปรับ `CACHE_TTL_SECONDS` ให้สอดคล้อง
- [ ] เพิ่ม endpoint ระดับน้ำ (BMA/RID/Chao Phraya) — ยังไม่พบ endpoint สดที่ยืนยันแล้ว
- [ ] เพิ่ม endpoint จุดน้ำท่วม (BMA) — ยังไม่พบ endpoint สดที่ยืนยันแล้ว
- [ ] เพิ่ม Radar เป็น proxy image/frame แทนลิงก์ตรง (กัน hotlink block และคุม cache)
- [ ] เพิ่มฐานข้อมูล/DB สำหรับเก็บย้อนหลัง (ตอนนี้ cache เป็น memory เท่านั้น หายเมื่อ restart)
- [ ] สร้าง Flood Risk Engine (Section 13) เมื่อมีข้อมูลระดับน้ำ + จุดน้ำท่วมแล้ว
- [ ] ตรวจเงื่อนไขการใช้งานข้อมูลของ TMD/BMA/RID ก่อนเผยแพร่สู่สาธารณะ

## ข้อจำกัดที่ควรรู้

- ภาพเรดาร์ตอนนี้เป็นลิงก์ตรงไป TMD (`weather.tmd.go.th/pic_bmancLoop.gif`) — ยังไม่ได้ proxy
  ผ่าน backend ถ้าโดน hotlink protection อาจไม่แสดงในบางเบราว์เซอร์
- Cache เป็น in-memory — ถ้า restart backend ข้อมูลย้อนหลังจะหายหมด (ต้องเพิ่ม DB ถ้าต้องการเก็บจริง)
- V1 นี้มีแค่ฝน — ยังไม่มีระดับน้ำ/จุดน้ำท่วม/Risk Engine ตามที่วางแผนไว้ใน V2-V4
